package com.example.aahaarapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;

public class Product extends AppCompatActivity {

    CardView ramp,braille,wheelChair,hearing ,walker,handrails,elbowStick,more;
    TextToSpeech tts;
    ImageView pro_micc;
    private static final int REQUEST_CODE_SPEECH_INPUT = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);


        tts=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                tts.setLanguage(Locale.US);
                tts.speak("Welcome to Products Section",TextToSpeech.QUEUE_ADD,null);
            }

        });

        ramp=findViewById(R.id.Ramps);
        braille=findViewById(R.id.braille);
        wheelChair=findViewById(R.id.wheelchair);
        hearing=findViewById(R.id.hearing);
        walker=findViewById(R.id.walker);
        handrails=findViewById(R.id.handrails);
        elbowStick=findViewById(R.id.elbowStick);
        more=findViewById((R.id.more));

        pro_micc =findViewById(R.id.pro_mic);

        //tv_Speech_to_text = findViewById(R.id.tv_speech_to_text);


        pro_micc.callOnClick();
        pro_micc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                tts.speak("Speak",TextToSpeech.QUEUE_ADD,null);
                Intent intent
                        = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,
                        Locale.getDefault());
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text");

                try {
                    startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
                }
                catch (Exception e) {
                    Toast
                            .makeText(Product.this, " " + e.getMessage(),
                                    Toast.LENGTH_SHORT)
                            .show();
                }
            }
        });

        ramp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webpage = Uri.parse("https://www.amazon.com/s?k=ramps");
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(webIntent);
            }
        });

        braille.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Braille");
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(webIntent);
            }
        });

        wheelChair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Wheelchairs");
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(webIntent);
            }
        });

        hearing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Hearing aids");
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(webIntent);
            }
        });

        walker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Walkers");
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(webIntent);
            }
        });

        handrails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Handrails");
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(webIntent);
            }
        });

        elbowStick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Elbow Stick");
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(webIntent);
            }
        });

        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri webpage = Uri.parse("https://www.amazon.com/s?k=");
                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                startActivity(webIntent);
            }
        });

}
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SPEECH_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> result = data.getStringArrayListExtra(
                        RecognizerIntent.EXTRA_RESULTS);
                String var = Objects.requireNonNull(result).get(0);
                System.out.println(var);
                //   Log.d(null,var);
                //   tv_Speech_to_text.setText(Objects.requireNonNull(result).get(0));
                tts.speak("thank you", TextToSpeech.QUEUE_ADD, null);
                // String    var="sos";
                //  ;var=="SOS"&&var=="sos
                //System.out.println(var);


                System.out.println(var);
                if (var.equals("WHEELCHAIRS") || var.equals("Wheelchairs")|| var.equals("wheelchair")|| var.equals("wheelchairs")|| var.equals("Wheel chairs")) {
                    Uri webpage = Uri.parse("https://www.amazon.com/s?k=Wheelchairs");
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                    startActivity(webIntent);
            }
                System.out.println(var);
                if (var.equals("RAMPS") || var.equals("RAMP")|| var.equals("ramps")|| var.equals("ramp")|| var.equals("Ramps")) {
                    Uri webpage = Uri.parse("https://www.amazon.com/s?k=ramps");
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                    startActivity(webIntent);
                }
                System.out.println(var);
                if (var.equals("HANDRAILS") || var.equals("handrails")|| var.equals("handrail")|| var.equals("HANDRAIL")|| var.equals("Handrail")) {
                    Uri webpage = Uri.parse("https://www.amazon.com/s?k=handrails");
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                    startActivity(webIntent);
                }
                System.out.println(var);
                if (var.equals("HEARING AIDS") || var.equals("hearing aids")|| var.equals("hearing aid")|| var.equals("hearing aids")|| var.equals("Hearing aid")) {
                    Uri webpage = Uri.parse("https://www.amazon.com/s?k=hearingaids");
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                    startActivity(webIntent);
                }
                System.out.println(var);
                if (var.equals("braille") || var.equals("BRAILLE")|| var.equals("Braille")) {
                    Uri webpage = Uri.parse("https://www.amazon.com/s?k=braille");
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                    startActivity(webIntent);
                }
                System.out.println(var);
                if (var.equals("WALKER") || var.equals("walker")|| var.equals("Walker")) {
                    Uri webpage = Uri.parse("https://www.amazon.com/s?k=walker");
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                    startActivity(webIntent);
                }
                System.out.println(var);
                if (var.equals("ELBOW STICK") || var.equals("elbow stick")|| var.equals("Elbow stick")|| var.equals("Elbow Stick")) {
                    Uri webpage = Uri.parse("https://www.amazon.com/s?k=elbowstick");
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                    startActivity(webIntent);
                }
                System.out.println(var);
                if (var.equals("more") || var.equals("MORE")|| var.equals("More")) {
                    Uri webpage = Uri.parse("https://www.amazon.com/s?k=disabledequiptments");
                    Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
                    startActivity(webIntent);
                }

            }}

}}