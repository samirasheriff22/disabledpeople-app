package com.example.aahaarapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;

public class equip extends AppCompatActivity {
    CardView ramps, brailles, wheels, hearinga, walkers, handrail, elbow, mores;
    TextToSpeech tts;
    ImageView equipm;
    private static final int REQUEST_CODE_SPEECH_INPUT = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equip);

        tts=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                tts.setLanguage(Locale.US);
                tts.speak("Welcome to Equipments Section",TextToSpeech.QUEUE_ADD,null);
            }

        });
        equipm = findViewById(R.id.equip_mic);
        ramps = findViewById(R.id.Ramps);
        brailles = findViewById(R.id.brailles);
        wheels = findViewById(R.id.wheels);
        hearinga = findViewById(R.id.hearinga);
        walkers = findViewById(R.id.walkers);
        handrail = findViewById(R.id.handrail);
        elbow = findViewById(R.id.elbow);
        mores = findViewById((R.id.more));

        equipm.callOnClick();
        equipm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                tts.speak("Speak",TextToSpeech.QUEUE_ADD,null);
                Intent intent
                        = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,
                        Locale.getDefault());
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text");

                try {
                    startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
                }
                catch (Exception e) {
                    Toast
                            .makeText(equip.this, " " + e.getMessage(),
                                    Toast.LENGTH_SHORT)
                            .show();
                }
            }
        });



        ramps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Search for school nearby
                Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=ramps");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

//        ramp.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Uri webpage = Uri.parse("https://www.amazon.com/s?k=ramps");
//                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
//                startActivity(webIntent);
//            }
//        });

//        braille.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Braille's");
//                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
//                startActivity(webIntent);
//            }
//        });
        brailles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Search for school nearby
                Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=braille");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
        wheels.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Search for school nearby
                Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=wheelchair");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

//        wheelChair.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Wheelchairs");
//                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
//                startActivity(webIntent);
//            }
//        });

//        hearing.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Hearing aids");
//                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
//                startActivity(webIntent);
//            }
//        });
        hearinga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Search for school nearby
                Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=hearingaids");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
//        walker.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Walkers");
//                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
//                startActivity(webIntent);
//            }
//        });
        walkers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Search for school nearby
                Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=adultwalkers");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

//        handrails.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Handrails");
//                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
//                startActivity(webIntent);
//            }
//        });
        handrail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Search for school nearby
                Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=handrails");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });

//        elbowStick.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Uri webpage = Uri.parse("https://www.amazon.com/s?k=Elbow Stick");
//                Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);
//                startActivity(webIntent);
//            }
//        });
        elbow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=elbowstick");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                startActivity(mapIntent);
            }
        });
//        mores.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // Search for school nearby
//                Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=disabled equipments");
//                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
//                mapIntent.setPackage("com.google.android.apps.maps");
//                startActivity(mapIntent);
//            }
//        });
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SPEECH_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> result = data.getStringArrayListExtra(
                        RecognizerIntent.EXTRA_RESULTS);
                String var = Objects.requireNonNull(result).get(0);
                System.out.println(var);
                //   Log.d(null,var);
                //   tv_Speech_to_text.setText(Objects.requireNonNull(result).get(0));
                tts.speak("thank you", TextToSpeech.QUEUE_ADD, null);
                // String    var="sos";
                //  ;var=="SOS"&&var=="sos
                //System.out.println(var);


                System.out.println(var);
                if (var.equals("WHEELCHAIRS") || var.equals("Wheelchairs")|| var.equals("wheelchair")|| var.equals("wheelchairs")|| var.equals("Wheel chairs")) {
                    Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=wheelchair");
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }
                System.out.println(var);
                if (var.equals("RAMPS") || var.equals("RAMP")|| var.equals("ramps")|| var.equals("ramp")|| var.equals("Ramps")) {

                        // Search for school nearby
                        Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=ramps");
                        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                        mapIntent.setPackage("com.google.android.apps.maps");
                        startActivity(mapIntent);
                }
                System.out.println(var);
                if (var.equals("HANDRAILS") || var.equals("handrails")|| var.equals("handrail")|| var.equals("HANDRAIL")|| var.equals("Handrail")) {
                    Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=handrails");
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }
                System.out.println(var);
                if (var.equals("HEARING AIDS") || var.equals("hearing aids")|| var.equals("hearing aid")|| var.equals("hearing aids")|| var.equals("Hearing aid")) {
                    Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=hearingaids");
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }
                System.out.println(var);
                if (var.equals("braille") || var.equals("BRAILLE")|| var.equals("Braille")) {
                    Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=braille");
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }
                System.out.println(var);
                if (var.equals("WALKER") || var.equals("walker")|| var.equals("Walker")) {
                    Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=adultwalkers");
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }
                System.out.println(var);
                if (var.equals("ELBOW STICK") || var.equals("elbow stick")|| var.equals("Elbow stick")|| var.equals("Elbow Stick")) {
                    Uri gmmIntentUri = Uri.parse("geo:0,0?z=10&q=elbowstick");
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }



            }}
}}


